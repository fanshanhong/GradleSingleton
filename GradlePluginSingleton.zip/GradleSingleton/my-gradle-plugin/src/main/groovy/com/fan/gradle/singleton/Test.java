package com.fan.gradle.singleton;

/**
 * @Description:
 * @Author: shanhongfan
 * @Date: 2021/5/24 13:44
 * @Modify:
 */
public class Test {
}
